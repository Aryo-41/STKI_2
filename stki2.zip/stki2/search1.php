<?php
include "index.php";
include "koneksi.php";
?>
<html>
	<form action='searchs1.php' method='GET'>
    	  <center> 
        	<p><font size="5" face="sans-serif"><br>
			<img src="assets/images/20201101_160552.png" alt="Google Title">
            <br><input type='text' size='50' name='keyword'> <input type='submit' value='Cari'></font></p>
   
      </center>
      </form>
</html>